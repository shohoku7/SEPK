package com.zzk.bean;

/**
 * 2015.05.28
 * �
 */
public class MemoType {
	private int typeId = 0;
	private String memoType = null;
	public int getTypeId() {
		return typeId;
	}
	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}
	public String getMemoType() {
		return memoType;
	}
	public void setMemoType(String memoType) {
		this.memoType = memoType;
	}
}
