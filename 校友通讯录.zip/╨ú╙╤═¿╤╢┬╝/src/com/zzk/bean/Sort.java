package com.zzk.bean;

/**
 * 2015.05.28
 * �
 */
public class Sort {
	private int sortId = 0;
	private String sortName = null;
	public int getSortId() {
		return sortId;
	}
	public void setSortId(int sortId) {
		this.sortId = sortId;
	}
	public String getSortName() {
		return sortName;
	}
	public void setSortName(String sortName) {
		this.sortName = sortName;
	}
}
